<?php
/**
 * The first widget area on the front page template.
 *
 * @package Forefront
 */
?>
<?php if ( is_active_sidebar( 'sidebar-3' ) ) : ?>
<div class="clear widget-area optional-widget-area" role="complementary">
	<div class="<?php forefront_widget_counter( 'sidebar-3' ); ?>">
		<?php dynamic_sidebar( 'sidebar-3' ); ?>
	</div>
</div>
<?php endif; ?>