<?php
/**
 * The template used for displaying testimonials.
 *
 * @package Forefront
 */
?>
<?php
	$additional_class = 'without-featured-image';
	if ( '' != get_the_post_thumbnail() )
		$additional_class = 'with-featured-image';
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( $additional_class ); ?>>
	<div class="entry-content">
		<?php the_content(); ?>
	</div>
	<?php if ( '' != get_the_post_thumbnail() ) : ?>
	<span class="testimonial-thumbnail">
		<?php the_post_thumbnail( 'forefront-testimonial-thumbnail' ); ?>
	</span>
	<?php endif; ?>
	<?php the_title( '<header class="entry-header"><h1 class="entry-title">', '</h1></header><!-- .entry-header -->' ); ?>
	<?php edit_post_link( __( 'Edit', 'forefront' ), '<footer class="entry-meta"><span class="edit-link">', '</span></footer>' ); ?>
</article><!-- #post-## -->