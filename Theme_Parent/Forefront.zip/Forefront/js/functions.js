( function( $ ){
	if ( $.isFunction( $.fn.masonry ) ) {
		var $testimonialsContainer = $( '#testimonials' ),
		    $widgetsContainer = $( '.more-than-three-widgets' );

		$testimonialsContainer.imagesLoaded( function() {
			$testimonialsContainer.masonry( {
				itemSelector: '.hentry',
				columnWidth: function( containerWidth ) {
					return containerWidth / 2;
				},
				isResizable: true,
				isAnimated: true,
				animationOptions: {
					duration: 200
				},
				isRTL: $( 'body' ).is( '.rtl' )
			} );
		} );

		$widgetsContainer.imagesLoaded( function() {
			$widgetsContainer.masonry( {
				itemSelector: '.widget',
				columnWidth: function( containerWidth ) {
					return containerWidth / 3;
				},
				isResizable: true,
				isAnimated: true,
				animationOptions: {
					duration: 200
				},
				isRTL: $( 'body' ).is( '.rtl' )
			} );
		} );
	}

	// Focus styles for tabable navigation.
	$( '.navigation-main' ).find( 'a' ).on( 'focus.forefront blur.forefront', function() {
		$( this ).parents().toggleClass( 'focus' );
	} );
} )( jQuery );