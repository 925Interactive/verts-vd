<?php
/**
 * The template for displaying Testimonial Archive pages.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package Forefront
 */

get_header(); ?>

<?php
$jetpack_options = get_theme_mod( 'jetpack_testimonials' );

$additional_class = 'without-featured-image';

if ( '' != $jetpack_options['featured-image'] )
	$additional_class = 'with-featured-image';
?>

	<div class="hero page-header <?php echo $additional_class; ?>">
		<?php
			if ( '' != $jetpack_options['featured-image'] )
				echo wp_get_attachment_image( (int)$jetpack_options['featured-image'], 'forefront-page-thumbnail' );
		?>
		<div>
			<div>
				<div>
					<h1 class="page-title">
					<?php
					if ( '' != $jetpack_options['page-title'] )
						echo esc_html( $jetpack_options['page-title'] );
					else
						_e( 'Testimonials', 'forefront' );
					?>
					</h1>
				</div>
			</div>
		</div>
	</div>

	<div id="primary" class="content-area full-width">
		<div id="content" class="site-content" role="main">

			<?php if ( '' != $jetpack_options['page-content'] ) : ?>

				<article class="hentry">
					<div class="entry-content">
						<?php echo convert_chars( convert_smilies( wptexturize( stripslashes( wp_filter_post_kses( addslashes( $jetpack_options['page-content'] ) ) ) ) ) ); ?>
					</div>
				</article>

			<?php endif; ?>

			<div id="testimonials" class="testimonials clear">
				<?php
					if ( have_posts() ):

					while ( have_posts() ) : the_post();

						get_template_part( 'content', 'testimonial' );

					endwhile;
				?>

				<?php else : ?>

					<p class="no-testimonial"><?php _e( 'Sorry, but no testimonial has been added yet.', 'forefront' ); ?></p>

				<?php endif; ?>
			</div>
		</div><!-- #content -->
	</div><!-- #primary -->

<?php get_footer(); ?>