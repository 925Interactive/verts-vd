<?php
/**
 * The template used for displaying child page on the grid template.
 *
 * @package Forefront
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'child-page' ); ?>>
	<?php if ( '' != get_the_post_thumbnail() ) : ?>
	<a href="<?php the_permalink(); ?>">
		<?php the_post_thumbnail( 'forefront-grid-thumbnail' ); ?>
	</a>
	<?php endif; ?>
	<?php the_title( '<header class="entry-header"><h1 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h1></header><!-- .entry-header -->' ); ?>
	<div class="entry-summary">
		<?php the_excerpt(); ?>
	</div>
	<?php edit_post_link( __( 'Edit', 'forefront' ), '<footer class="entry-meta"><span class="edit-link">', '</span></footer>' ); ?>
</article><!-- #post-## -->
