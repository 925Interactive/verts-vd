<?php
/**
 * The second widget area on the front page template.
 *
 * @package Forefront
 */
?>
<?php if ( is_active_sidebar( 'sidebar-4' ) ) : ?>
<div class="clear widget-area optional-widget-area front-page-widget-area-two" role="complementary">
	<div class="<?php forefront_widget_counter( 'sidebar-4' ); ?>">
		<?php dynamic_sidebar( 'sidebar-4' ); ?>
	</div>
</div>
<?php endif; ?>