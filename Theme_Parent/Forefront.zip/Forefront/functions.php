<?php
/**
 * forefront functions and definitions
 *
 * @package Forefront
 */

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) )
	$content_width = 600; /* pixels */

/**
 * Adjusts content_width value for few pages and attachment templates.
 */
function forefront_content_width() {
	global $content_width;
	if ( is_page_template( 'page-templates/front-page.php' ) )
		$content_width = 510;

	if ( is_page_template( 'page-templates/full-width-page.php' )
	  || is_page_template( 'page-templates/testimonials-page.php' )
	  || is_page_template( 'page-templates/grid-page.php' )
	  || is_attachment() )
		$content_width = 1050;
}
add_action( 'template_redirect', 'forefront_content_width' );

if ( ! function_exists( 'forefront_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which runs
 * before the init hook. The init hook is too late for some features, such as indicating
 * support post thumbnails.
 */
function forefront_setup() {

	/**
	 * Custom template tags for this theme.
	 */
	require( get_template_directory() . '/inc/template-tags.php' );

	/**
	 * Custom functions that act independently of the theme templates
	 */
	require( get_template_directory() . '/inc/extras.php' );

	/**
	 * Customizer additions
	 */
	require( get_template_directory() . '/inc/customizer.php' );

	/**
	 * Make theme available for translation
	 * Translations can be filed in the /languages/ directory
	 * If you're building a theme based on forefront, use a find and replace
	 * to change 'forefront' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'forefront', get_template_directory() . '/languages' );

	/**
	 * Add default posts and comments RSS feed links to head
	 */
	add_theme_support( 'automatic-feed-links' );

	/**
	 * Enable support for Post Thumbnails on posts and pages
	 */
	add_theme_support( 'post-thumbnails' );

	/**
	 * Adding several sizes for Post Thumbnails
	 */
	add_image_size( 'forefront-testimonial-thumbnail', 68, 68, true );
	add_image_size( 'forefront-grid-thumbnail', 330, 330, true );
	add_image_size( 'forefront-blog-thumbnail', 810, 0 );
	add_image_size( 'forefront-page-thumbnail', 1230, 0 );

	/**
	 * This theme uses wp_nav_menu() in one location.
	 */
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'forefront' ),
	) );

	/**
	 * Enable support for Post Formats
	 */
	add_theme_support( 'post-formats', array( 'aside', 'image', 'video', 'quote', 'link' ) );

	/**
	 * This theme allows users to set a custom background.
	 */
	add_theme_support( 'custom-background', apply_filters( 'forefront_custom_background_args', array(
		'default-color' => 'f0f2f0',
	) ) );

	/*
	 * Switch default core markup for search form and comment form
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form',
	) );
}
endif; // forefront_setup
add_action( 'after_setup_theme', 'forefront_setup' );

/**
 * Register widgetized area and update sidebar with default widgets
 */
function forefront_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Sidebar', 'forefront' ),
		'id'            => 'sidebar-1',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );

	register_sidebar( array(
		'name'          => __( 'Footer Widget Area', 'forefront' ),
		'id'            => 'sidebar-2',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );

	register_sidebar( array(
		'name'          => __( 'Front Page Widget Area One', 'forefront' ),
		'id'            => 'sidebar-3',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );

	register_sidebar( array(
		'name'          => __( 'Front Page Widget Area Two', 'forefront' ),
		'id'            => 'sidebar-4',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );
}
add_action( 'widgets_init', 'forefront_widgets_init' );

/**
 * Count the number of widgets and create a class name.
 */
function forefront_widget_counter( $sidebar_id ) {
	$the_sidebars = wp_get_sidebars_widgets();

	if ( ! isset( $the_sidebars[$sidebar_id] ) )
		$count = 0;
	else
		$count = count( $the_sidebars[$sidebar_id] );

	switch ( $count ) {
		case '1':
			$class = 'one-widget';
			break;
		case '2':
			$class = 'two-widgets';
			break;
		case '3':
			$class = 'three-widgets';
			break;
		default :
			$class = 'more-than-three-widgets';
	}

	echo $class;
}

/**
 * Returns the Google font stylesheet URL if available.
 *
 * The use of Open Sans by default is localized. For languages that use
 * characters not supported by the font, the font can be disabled.
 *
 * @return string Font stylesheet or empty string if disabled.
 */
function forefront_get_font_url() {
	$font_url = '';

	/* translators: If there are characters in your language that are not supported
	 by Open Sans, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== _x( 'on', 'Open Sans font: on or off', 'forefront' ) ) {
		$subsets = 'latin,latin-ext';

		/* translators: To add an additional Open Sans character subset specific to your language, translate
		 this to 'greek', 'cyrillic' or 'vietnamese'. Do not translate into your own language. */
		$subset = _x( 'no-subset', 'Open Sans font: add new subset (greek, cyrillic, vietnamese)', 'forefront' );

		if ( 'cyrillic' == $subset )
			$subsets .= ',cyrillic,cyrillic-ext';
		elseif ( 'greek' == $subset )
			$subsets .= ',greek,greek-ext';
		elseif ( 'vietnamese' == $subset )
			$subsets .= ',vietnamese';

		$protocol = is_ssl() ? 'https' : 'http';
		$query_args = array(
			'family' => 'Open+Sans:400italic,600italic,700italic,400,600,700',
			'subset' => $subsets,
		);
		$font_url = add_query_arg( $query_args, "$protocol://fonts.googleapis.com/css" );
	}

	return $font_url;
}

/**
 * Enqueue scripts and styles
 */
function forefront_scripts() {
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/genericons/genericons.css', array(), '3.0.3' );

	wp_enqueue_style( 'forefront-style', get_stylesheet_uri(), array( 'genericons' ) );

	wp_enqueue_script( 'forefront-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20130121', true );

	wp_enqueue_script( 'forefront-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20130115', true );

	if ( is_page_template( 'page-templates/testimonials-page.php' )
	  || is_page_template( 'page-templates/front-page.php' )
	  || is_post_type_archive( 'jetpack-testimonial' )
	  || is_active_sidebar( 'sidebar-2' ) ) {
		wp_enqueue_script( 'jquery-masonry' );
	}

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );

	if ( is_singular() && wp_attachment_is_image() )
		wp_enqueue_script( 'forefront-keyboard-image-navigation', get_template_directory_uri() . '/js/keyboard-image-navigation.js', array( 'jquery' ), '20120202' );

	$font_url = forefront_get_font_url();
	if ( ! empty( $font_url ) )
		wp_enqueue_style( 'forefront-fonts', esc_url_raw( $font_url ), array(), null );

	wp_enqueue_script( 'forefront-functions', get_template_directory_uri() . '/js/functions.js', array( 'jquery' ), '20140213', true );
}
add_action( 'wp_enqueue_scripts', 'forefront_scripts' );

/**
 * Appends post title to Aside and Quote posts
 *
 * @param string $content
 * @return string
 */
function forefront_conditional_title( $content ) {

	if ( has_post_format( 'aside' ) || has_post_format( 'quote' ) ) {
		if ( ! is_singular() )
			$content .= the_title( '<h1 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h1>', false );
		else
			$content .= the_title( '<h1 class="entry-title">', '</h1>', false );
	}

	return $content;
}
add_filter( 'the_content', 'forefront_conditional_title', 0 );

/**
 * Returns a "Read More" link for excerpts
 *
 */
function forefront_read_more_link() {
	return ' <a href="'. esc_url( get_permalink() ) . '" class="more-link">' . __( 'Read More <span class="meta-nav">&rarr;</span>', 'forefront' ) . '</a>';
}

/**
 * Replaces "[...]" (appended to automatically generated excerpts) with an ellipsis and forefront_read_more_link().
 */
function forefront_auto_excerpt_more( $more ) {
	return ' &hellip;' . forefront_read_more_link();
}
add_filter( 'excerpt_more', 'forefront_auto_excerpt_more' );

/**
 * Change a class on the hero area depending on featured image.
 */
function forefront_additional_class() {

	if ( is_archive() || is_search() || is_404() || '' == get_the_post_thumbnail() ) {
		$additional_class =  'without-featured-image';
	} else {
		$additional_class =  'with-featured-image';
	}

	return $additional_class;
}

/**
 * Get random posts; a simple, more efficient approach.
 * MySQL queries that use ORDER BY RAND() can be pretty challenging and slow on large datasets.
 * Also it works better with heavy caching.
 */
function forefront_get_random_posts( $number = 1, $post_type = 'post' ) {
	$query = new WP_Query( array(
		'posts_per_page' => 100,
		'fields'         => 'ids',
		'post_type'      => $post_type
	) );

	$post_ids = $query->posts;
	shuffle( $post_ids );
	$post_ids = array_splice( $post_ids, 0, $number );

	$random_posts = get_posts( array(
		'post__in'    => $post_ids,
		'numberposts' => count( $post_ids ),
		'post_type'   => $post_type
	) );

	return $random_posts;
}

/**
 * Implement the Custom Header feature
 */
require( get_template_directory() . '/inc/custom-header.php' );

/**
 * Load Jetpack compatibility file.
 */
if ( file_exists( get_template_directory() . '/inc/jetpack.php' ) )
	require( get_template_directory() . '/inc/jetpack.php' );
