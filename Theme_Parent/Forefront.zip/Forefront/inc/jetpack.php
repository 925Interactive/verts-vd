<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package Forefront
 */

/**
 * Add theme support for Infinite Scroll.
 * See: http://jetpack.me/support/infinite-scroll/
 */
function forefront_infinite_scroll_setup() {
	add_theme_support( 'infinite-scroll', array(
		'container' => 'content',
		'footer'    => 'page',
	) );
}
add_action( 'after_setup_theme', 'forefront_infinite_scroll_setup' );

/**
 * Do we have footer widgets? Or is it viewed from iPad or mobile?
 * If so let's switch to the "click to load" type IS
 *
 * @return bool
 */

function forefront_has_footer_widgets( $has_widgets ) {
	if ( Jetpack_User_Agent_Info::is_ipad() || ( function_exists( 'jetpack_is_mobile' ) && jetpack_is_mobile() ) || is_active_sidebar( 'sidebar-2' ) )

		return true;

	return $has_widgets;
}
add_filter( 'infinite_scroll_has_footer_widgets', 'forefront_has_footer_widgets' );

/**
 * Add theme support for Social Links
 * See: http://jetpack.me/support/social-links/
 */
function forefront_social_links() {
	add_theme_support( 'social-links', array(
		'facebook',
		'twitter',
		'linkedin',
		'tumblr',
		'google_plus',
	) );
}
add_action( 'after_setup_theme', 'forefront_social_links' );

/**
 * Add support for Testimonial Post Type
 */
function forefront_testimonial() {
	add_theme_support( 'jetpack-testimonial' );
}
add_action( 'after_setup_theme', 'forefront_testimonial' );

/**
 * Flush rewrite rules for Testimonial CPT on setup and switch
 */
function forefront_flush_rewrite_rules() {
     flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'forefront_flush_rewrite_rules' );

/**
 * Modify the query in the testimonial archive page.
 */
function forefront_testimonial_archive( $arg ) {
	if ( $arg -> is_post_type_archive( 'jetpack-testimonial' ) && ! is_page_template( 'page-templates/front-page.php' ) ) {
		 $arg -> set( 'orderby', 'menu_order' );
		 $arg -> set( 'order', 'ASC' );
		 $arg -> set( 'post_type', 'jetpack-testimonial' );
		 $arg -> set( 'posts_per_page', '999' );
	}
}
add_action( 'pre_get_posts', 'forefront_testimonial_archive' );