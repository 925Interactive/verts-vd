<?php
/**
 * forefront Theme Customizer
 *
 * @package Forefront
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function forefront_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	// Rename the section
	$wp_customize->get_section( 'title_tagline' )->title = __( 'Site Title', 'forefront' );

	// Remove Tagline because it is hidden.
	$wp_customize->remove_control('blogdescription');

	// Rename the label to "Display Site Title & Tagline" in order to make this option extra clear.
	$wp_customize->get_control( 'display_header_text' )->label = __( 'Display Site Title', 'forefront' );

	// Rename the label to "Site Title Color" because this only affects the site title in this theme.
	$wp_customize->get_control( 'header_textcolor' )->label = __( 'Site Title Color', 'forefront' );

}
add_action( 'customize_register', 'forefront_customize_register' );

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function forefront_customize_preview_js() {
	wp_enqueue_script( 'forefront-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20140117', true );
}
add_action( 'customize_preview_init', 'forefront_customize_preview_js' );