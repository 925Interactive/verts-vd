<?php
/**
 * Sample implementation of the Custom Header feature
 * http://codex.wordpress.org/Custom_Headers
 *
 * @package Forefront
 */

/**
 * Setup the WordPress core custom header feature.
 *
 * @uses forefront_header_style()
 * @uses forefront_admin_header_style()
 * @uses forefront_admin_header_image()
 *
 * @package Forefront
 */
function forefront_custom_header_setup() {
	add_theme_support( 'custom-header', apply_filters( 'forefront_custom_header_args', array(
		'default-image'          => '',
		'default-text-color'     => '050705',
		'width'                  => 330,
		'height'                 => 72,
		'flex-height'            => true,
		'flex-width'             => true,
		'wp-head-callback'       => 'forefront_header_style',
		'admin-head-callback'    => 'forefront_admin_header_style',
		'admin-preview-callback' => 'forefront_admin_header_image',
	) ) );
}
add_action( 'after_setup_theme', 'forefront_custom_header_setup' );

if ( ! function_exists( 'forefront_header_style' ) ) :
/**
 * Styles the header image and text displayed on the blog
 *
 * @see forefront_custom_header_setup().
 */
function forefront_header_style() {
	$text_color = get_header_textcolor();

	// If no custom options for text are set, let's bail
	if ( display_header_text() && $text_color === get_theme_support( 'custom-header', 'default-text-color' ) )
		return;

	// If we get this far, we have custom styles. Let's do this.
	?>
	<style type="text/css">
	<?php
		// Has the text been hidden?
		if ( ! display_header_text() ) :
	?>
		.site-title,
		.site-description {
			clip: rect(1px 1px 1px 1px); /* IE6, IE7 */
			clip: rect(1px, 1px, 1px, 1px);
			position: absolute;
		}
	<?php
		// If the user has set a custom color for the text use that
		elseif ( $text_color != get_theme_support( 'custom-header', 'default-text-color' ) ) :
	?>
		.site-title a {
			color: #<?php echo get_header_textcolor(); ?>;
		}
	<?php endif; ?>
	</style>
	<?php
}
endif; // forefront_header_style

if ( ! function_exists( 'forefront_admin_header_style' ) ) :
/**
 * Styles the header image displayed on the Appearance > Header admin panel.
 *
 * @see forefront_custom_header_setup().
 */
function forefront_admin_header_style() {
?>
	<style type="text/css">
	.appearance_page_custom-header #headimg {
		border: none;
		min-height: 30px;
	}
	#headimg h1 {
		font-family: "Open Sans", Helvetica, Arial, sans-serif;
		font-size: 22px;
		font-weight: 700;
		letter-spacing: -0.025em;
		line-height: 1.0909090909;
		margin: 0;
	}
	#headimg h1 a {
		text-decoration: none;
	}
	#headimg img {
		height: auto;
		margin-bottom: 12px;
		max-width: 330px;
		vertical-align: middle;
	}
	</style>
<?php
}
endif; // forefront_admin_header_style

if ( ! function_exists( 'forefront_admin_header_image' ) ) :
/**
 * Custom header image markup displayed on the Appearance > Header admin panel.
 *
 * @see forefront_custom_header_setup().
 */
function forefront_admin_header_image() { ?>
	<div id="headimg">
		<?php if ( get_header_image() ) : ?>
			<img src="<?php header_image(); ?>" alt="" />
		<?php endif; ?>
		<h1 class="displaying-header-text"><a id="name"<?php echo sprintf( ' style="color:#%s;"', get_header_textcolor() ); ?> onclick="return false;" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a></h1>
		</div>
	</div>
<?php }
endif; // forefront_admin_header_image